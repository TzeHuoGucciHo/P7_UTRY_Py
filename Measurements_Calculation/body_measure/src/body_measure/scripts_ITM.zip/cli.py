import argparse, json, os, sys, time
from body_measure import measure_v2 as M
import os
import cv2
import numpy as np

def load_image(path: str) -> np.ndarray:
    """Robust billedindlæsning (understøtter også Windows-stier med mellemrum/unicode)."""
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Image not found: {path}")
    # Brug imdecode for at undgå problemer med unicode-stier
    data = np.fromfile(path, dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Failed to read image: {path}")
    return img


def _to_worksheet_schema(res: dict) -> dict:
    """
    Mapper til ønskede kolonnenavne.
    Ignorerer bevidst: Gender, Age, HeadCircumference, Belly, ArmLength,
    ShoulderToWaist, WaistToKnee, LegLength.
    """
    return {
        "ShoulderWidth": res.get("shoulder_width_cm"),
        "ChestWidth":    res.get("chest_width_cm"),
        "Waist":         res.get("waist_cm"),
        "Hips":          res.get("hip_cm"),
        "TotalHeight":   res.get("input_height_cm"),  # direkte den indtastede højde
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--front", required=True)
    ap.add_argument("--side",  required=True)
    ap.add_argument("--height-cm", type=float, default=None)
    ap.add_argument("--backend", choices=["deeplabv3","opencv","auto"], default="deeplabv3")
    ap.add_argument("--device", choices=["cuda","cpu"], default="cuda")
    ap.add_argument("--debug-dir", default=None)
    ap.add_argument("--save-masks", action="store_true")
    ap.add_argument("--setup-load", default=None)
    ap.add_argument("--setup-save", default=None)
    ap.add_argument("--calibrate-many", default=None)
    ap.add_argument("--aruco-mm", type=float, default=None)
    ap.add_argument("--target-height", type=int, default=None)
    ap.add_argument("--crop-margin", type=float, default=None)
    ap.add_argument("--no-profile-scale", action="store_true")
    ap.add_argument("--print-runtime-info", action="store_true")
    ap.add_argument("--out-json", default=None, help="Gem resultat som JSON til denne sti")
    args = ap.parse_args()

    if args.print_runtime_info:
        try:
            import inspect
            sig = inspect.signature(M.compute)
            print(f"body_measure file: {M.__file__}")
            print(f"measure file     : {getattr(M, '__file__', 'unknown')}")
            print(f"compute signature: {sig}")
        except Exception:
            pass

    front = load_image(args.front)
    side  = load_image(args.side)

    kwargs = dict(
        front_bgr=front,
        side_bgr=side,
        height_cm=args.height_cm,
        debug_dir=args.debug_dir,
        save_masks=args.save_masks,
        prefer_backend=args.backend,
        device=args.device,
        setup_load=args.setup_load,
        setup_save=args.setup_save,
        calibrate_many=args.calibrate_many,
        aruco_mm=args.aruco_mm,
        no_profile_scale=args.no_profile_scale,
    )
    if args.target_height is not None:
        kwargs["target_height_px"] = args.target_height
    if args.crop_margin is not None:
        kwargs["crop_margin_ratio"] = args.crop_margin

    t0 = time.time()
    res = M.compute(**kwargs)
    dt = time.time() - t0

    chest   = res.get("chest_cm")
    waist   = res.get("waist_cm")
    hip     = res.get("hip_cm")
    thigh   = res.get("thigh_cm")
    shoulder= res.get("shoulder_width_cm")
    inseam  = res.get("inseam_cm")
    chest_w = res.get("chest_width_cm")

    print(
        f"[ok] chest={chest:.2f}cm  chest_width={chest_w:.2f}cm  waist={waist:.2f}cm  hip={hip:.2f}cm  "
        f"thigh={thigh:.2f}cm  shoulder_width={shoulder:.2f}cm  inseam={inseam:.2f}cm  time={dt:.2f}s"
    )

    # Byg worksheet-blokken
    worksheet = _to_worksheet_schema(res)
    res_out = dict(res)
    res_out["worksheet"] = worksheet  # <— læg ind i JSON

    # Skriv til fil hvis ønsket
    if args.out_json:
        os.makedirs(os.path.dirname(os.path.abspath(args.out_json)), exist_ok=True)
        with open(args.out_json, "w", encoding="utf-8") as f:
            json.dump(res_out, f, indent=2, ensure_ascii=False)

    # Print hele JSON til stdout også (valgfrit – praktisk til piping)
    try:
        print(json.dumps(res_out, indent=2, ensure_ascii=False))
    except Exception:
        pass

if __name__ == "__main__":
    main()
